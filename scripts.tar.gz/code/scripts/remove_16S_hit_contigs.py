from sys import argv
import pandas as pd
from Bio import SeqIO

# argv[1] = path to barrnap output 
# argv[2] = path to good_viral_contigs fasta 
# argv[3] = path for output file

# import first column of barrnap output (containing the names of contigs that were hit)
df = pd.read_csv(argv[1], sep = '\t', usecols=[0], comment='#', names=['contig'])

# convert column to list of unique contig names
bad_contigs = list(df['contig'].unique())

# read through good_viral_contigs fasta and only keep contigs not in bad_contigs list
keep_contigs = []
for record in SeqIO.parse(argv[2], 'fasta'):
    if record.id not in bad_contigs:
        keep_contigs.append(record)

# write kept contigs to file
SeqIO.write(keep_contigs,argv[3],'fasta')