from ast import arg
import pandas as pd
from sys import argv
# import numpy as np
from Bio import SeqIO
# from collections import Counter

# input variable
# argv[1] = output of blasting spike vs contigs
# argv[2] = contig multifasta
# argv[3] = fasta file containing spike sequence
# argv[4] = output fasta path

def check_total_bases_covered(df):
    new_df = {'sseqid':[], 'slen':[], 'covered_base_length': []}
    for i in df['sseqid'].unique():
        ranges = 0
        ranges = set()
        for index, row in df[df['sseqid'] == i].iterrows():
            start = min([row['sstart'], row['send']])
            end = max([row['sstart'], row['send']])
            ranges.update(range(start - 1 , end))
        new_df['sseqid'].append(i)
        new_df['slen'].append(row['slen'])
        new_df['covered_base_length'].append(len(ranges))  # issue around here where simple table contains some with value > 1
    new_df = pd.DataFrame.from_dict(new_df)
    return new_df

# load in blast database
df = pd.read_csv(argv[1], sep = '\t', names=['qseqid', 'sseqid', 'pident', 'length', 'mismatch', 'gapopen', 'qstart', 'qend', 'qlen', 'sstart', 'send', 'slen', 'evalue', 'bitscore'])

# store length of spike sequence
spike_length = df['qlen'].unique()[0]

# filter to remove hits with < 90% id
df = df[df['pident'] > 90]

# calculate how many bases for each contig covered by blast vs spike
df = check_total_bases_covered(df)

# filter to keep only contigs that are matched > 90% of their contigs length or where where the spike is covered by >90 % (this latter filter will allow any chimeras to be caught)
df = df[(df['covered_base_length'] > df['slen'] * 0.9) | (df['covered_base_length'] > spike_length * 0.9)]

# identify contig covered the greatest amount by spike
spike_hit = df.sort_values(by='covered_base_length', ascending=False).iloc[0]['sseqid']

# load in contig fasta and collect NON-spike contigs 
keep_contigs = []
for record in SeqIO.parse(argv[2], 'fasta'):
    if record.id != spike_hit:
        keep_contigs.append(record)

# append fasta sequence of the spike
for record in SeqIO.parse(argv[3], 'fasta'):
    keep_contigs.append(record)

# write all contigs to file
SeqIO.write(keep_contigs,argv[4],'fasta')
