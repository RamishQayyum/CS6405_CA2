import pandas as pd
from sys import argv
import numpy as np
import multiprocessing
from functools import partial

# input variable
# argv[1] = pid cut off as % 
# argv[2] = length cut off as proportion i.e. 90% = 0.9
# argv[3] = output file path
# argv[4] = thread count
# argv[5] onward =  blast file path

def split_df_for_multiproc(df,threads):
    chunk_size = int(len(df['qseqid'].unique())/threads)
    if chunk_size == 0:
        chunk_size = 1
    chunk_names = [list(df['qseqid'].unique())[i:i + chunk_size] for i in range(0, len(df['qseqid'].unique()), chunk_size)]
    chunks = [df[df['qseqid'].isin(chunk)] for chunk in chunk_names]
    pool = multiprocessing.Pool(processes=threads)
    return chunks, pool

def multiprocess_check_total_bases_covered(df):
    new_df = {'qseqid':[], 'qlen':[], 'covered_base_length': []}
    for i in df['qseqid'].unique():
        ranges = 0
        ranges = set()
        for index, row in df[df['qseqid'] == i].iterrows():
            start = min([row['qstart'], row['qend']])
            end = max([row['qstart'], row['qend']])
            ranges.update(range(start - 1 , end))
        new_df['qseqid'].append(i)
        new_df['qlen'].append(row['qlen'])
        new_df['covered_base_length'].append(len(ranges))  # issue around here where simple table contains some with value > 1
    new_df = pd.DataFrame.from_dict(new_df)
    return new_df

# create empty list to hold good contigs
good_contigs = []

# iterate over each of the blast files
for i in argv[5:]:

    # convert blast input to pandas dataframe
    df = pd.read_csv(i, sep = '\t', names=['qseqid', 'sseqid', 'pident', 'length', 'mismatch', 'gapopen', 'qstart', 'qend', 'qlen', 'sstart', 'send', 'slen', 'evalue', 'bitscore', 'staxids', 'stitle'])
    
    # filter df to remove matches that have less than argv[1] % matching identity
    df = df[df['pident'] >= float(argv[1])]
    
    # append this df to list of others that pass given threshold
    good_contigs.append(df)

# concatenate list of dataframe into one big dataframe
good_contigs = pd.concat(good_contigs).reset_index(drop=True)

# split df ahead of multiprocessing
chunks, pool = split_df_for_multiproc(good_contigs, int(argv[4]))

# look for overall coverage across databases
good_contigs = pd.concat(pool.map(partial(multiprocess_check_total_bases_covered), chunks)).reset_index(drop=True)

# calculate proportion of contig covered by hits
good_contigs['prop_covered'] = good_contigs['covered_base_length'] / good_contigs['qlen'] 
print(good_contigs)

# filter contigs to keep only those with argv[2] proportion of the contig covered by blast hits
good_contigs = good_contigs[good_contigs['prop_covered'] >= float(argv[2])].reset_index(drop=True)

# convert passing contigs to list of contig names
good_contigs = list(good_contigs['qseqid'].unique())

# write list of accessions to keep to file
with open(argv[3], 'w') as outfile:
    for contig in good_contigs:
        outfile.write('{}\n'.format(contig))
