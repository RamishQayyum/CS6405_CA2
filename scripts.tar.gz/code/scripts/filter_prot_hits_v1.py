import pandas as pd
from sys import argv
import numpy as np
from Bio import SeqIO
from collections import Counter

# input variable
# argv[1] = all contigs prodigal faa
# argv[2] = blast vs refseq viral protein filepath
# argv[3] = hmm vs phrogs database filepath
# argv[4] = hmm vs inovirus database filepath
# argv[5] = output file path

################## process blast vs refseq ####################

# get blast input as pandas dataframe
df = pd.read_csv(argv[2], sep = '\t', names=['qseqid', 'sseqid', 'pident', 'length', 'mismatch', 'gapopen', 'qstart', 'qend', 'qlen', 'sstart', 'send', 'slen', 'evalue', 'bitscore'])

# get list of orfs hit from blast table
all_orfs_hit = list(df['qseqid'].unique())

###############################################################

################### process hmm vs phrogs #####################

# get hmm input as pandas dataframe
df = pd.read_csv(argv[3],delim_whitespace=True, comment='#', names = ['sseqid', 'qseqid'], usecols=[0,2])

# append hmm orfs to list of orfs hit
all_orfs_hit += list(df['qseqid'].unique())

###############################################################

############### process hmm vs inovirus #######################

# get hmm input as pandas dataframe
df = pd.read_csv(argv[4],delim_whitespace=True, comment='#', names = ['sseqid', 'qseqid'], usecols=[0,2])

# append hmm orfs to list of orfs hit
all_orfs_hit += list(df['qseqid'].unique())

###############################################################

############# identify contigs passing filtering ##############

# get overall unique orf names hit
unique_orfs_hit = list(set(all_orfs_hit))

# convert orf names to contig name 
unique_orfs_hit = ['_'.join(x.split('_')[:-1]) for x in unique_orfs_hit]

# count the times a contig name appears in the list and export that as a dataframe (i.e. contig name appears 2x = hit orf count of 2)
unique_orfs_hit = pd.DataFrame.from_dict(Counter(unique_orfs_hit), orient='index').reset_index()

# fix column names
unique_orfs_hit.columns = ['contig', 'hit_orf_count']

# create empty list to hold contig name for computing total orf counts
contig_orf_count = []

# iterate through each orf in faa and add the associated contig name a list 
for record in SeqIO.parse(argv[1], 'fasta'):
    contig_orf_count.append('_'.join(record.id.split('_')[:-1]))

# count the times a contig name appears in the list and export that as a dataframe (i.e. contig name appears 2x = total orf count of 2)
contig_orf_count = pd.DataFrame.from_dict(Counter(contig_orf_count), orient='index').reset_index()

# fix column names
contig_orf_count.columns = ['contig', 'orf_count']

# combine the hit orf count df and total orf counts dfs
contig_orf_count = contig_orf_count.merge(unique_orfs_hit, on='contig')

# remove any contigs that have <= 2 orfs unless both orfs have been hit, and those where less than 3 orfs have been hit or orfs hit account for < 50% of the contig
contig_orf_count = contig_orf_count[(contig_orf_count['orf_count'] > 2) | ((contig_orf_count['orf_count'] == 2) & (contig_orf_count['hit_orf_count'] == 2))]

# remove any contigs that have less than 2 orf hits where both orfs have not been hit,  and any contigs with less than 3 orfs hit or those where 3 or more have been hit but that this accounts for less than 50% of their total orf count
contig_orf_count = contig_orf_count[(
    (
        (contig_orf_count['orf_count'] == 2) & 
        (contig_orf_count['hit_orf_count'] == 2)
    ) |
    (
        (contig_orf_count['hit_orf_count'] >= 3) &
        (contig_orf_count['hit_orf_count'] >= contig_orf_count['orf_count'] * 0.5)
    )
)]

# make a contig names that pass that filter
good_contigs = list(set(contig_orf_count['contig']))

###############################################################

################## write output to file #######################

# write list of the good contigs to file
with open(argv[5], 'w') as outfile:
    for contig in good_contigs:
        outfile.write('{}\n'.format(contig))

###############################################################