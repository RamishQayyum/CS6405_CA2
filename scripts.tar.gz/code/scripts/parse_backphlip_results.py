import pandas as pd
from sys import argv

# input variable
# argv[1] = cut off for each lifestyle type
# argv[2] = bacphlip input path
# argv[3] = output file path

# import bacphlip dataframe
df = pd.read_csv(argv[2], sep='\t')

# rename columns
df.columns = ['contig', 'virulent', 'temperate']

# create a result column that just says which ones are virulent vs temperate based on the argv[1] cutoff
df['result'] = df.apply(lambda x: 'virulent' if x['virulent'] >= float(argv[1]) and x['temperate'] < float(argv[1]) else ('temperate' if x['temperate'] >= float(argv[1]) and x['virulent'] < float(argv[1]) else 'undetermined'), axis=1)

# write new table to file
df.to_csv(argv[3], sep='\t', index=False)