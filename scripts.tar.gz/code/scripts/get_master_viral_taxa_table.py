from sys import argv
from glob import glob
import pandas as pd
import numpy as np

# argv[1] = path to vcontact2 genome_by_genome_overview.csv for viral contig db
# argv[2] = path to DemoVir_assignments.txt for viral contig db
# argv[3] = path to parsed bacphlip output file (XXXX.bacphlip_filtered) for viral contig db
# argv[4] = path to Host_prediction_to_genus_m90.csv from iphop for viral contig db
# argv[5] = desired output path for master taxa doc

############## process vcontact2 df ####################

# import vcontact2 dataframe
vcontact_df = pd.read_csv(argv[1])

# collect list of VCs that hit the phage in the contig db
hit_vcs = [x for x in vcontact_df['VC'][(vcontact_df['Genome'].str.split('~').str[-1].str.startswith('k141_'))].unique() if str(x) != 'nan']

# make a dataframe containing only contigs from contig db
contig_df = vcontact_df[(vcontact_df['Genome'].str.split('~').str[-1].str.startswith('k141_'))].reset_index(drop=True)
contig_df = contig_df[['Genome', 'VC Status', 'VC', 'VC Size']]

# create a dataframe containing relatives to the contigs db... i.e. those belonging to the hit VCs
relatives_df = vcontact_df[((vcontact_df['VC'].isin(hit_vcs)) & (~vcontact_df['Genome'].str.split('~').str[-1].str.startswith('k141_')))].reset_index(drop=True)

# cycle through contig db VCs and extract most commmon taxa for each VC
VC_taxa_df = {'VC': [], 'Kingdom': [], 'Phylum': [], 'Class': [], 'Order': [], 'Family': [], 'Genus': []}
for i in hit_vcs:
    sub_df = relatives_df[relatives_df['VC'] == i]
    VC_taxa_df['VC'].append(i)
    for j in ['Kingdom', 'Phylum', 'Class', 'Order', 'Family', 'Genus']:
        if len(sub_df) == 0:
            VC_taxa_df[j].append('Unassigned')
        else:
            taxa = sub_df.groupby(['VC'])[j].agg(lambda x: x.value_counts().index[0]).reset_index()
            taxa.columns = ['VC', 'taxa']
            VC_taxa_df[j].append(taxa['taxa'].iloc[0])
VC_taxa_df = pd.DataFrame.from_dict(VC_taxa_df)

# merge the VC taxa df with the contig df
contig_df = contig_df.merge(VC_taxa_df, on='VC', how='left')

# add column to say that these taxa were assigned via vcontact2
contig_df['taxa_tool'] = 'vcontact2'

########################################################

################# process demovir ######################

def update_demovir_taxa(x_VC, x_Genome, x_Order, x_Family, x_Genus, x_taxa_tool, demovir_df):
    if ((x_Order == 'Unassigned') and (x_Family == 'Unassigned') and (x_Genus == 'Unassigned')) or (pd.isnull(x_VC)):
        sub_df = demovir_df[demovir_df['Sequence_ID'] == x_Genome]
        if len(sub_df) > 0:
            order = sub_df['Order'].iloc[0]
            family = sub_df['Family'].iloc[0]
            tool = 'demovir'
        else:
            order = x_Order
            family = x_Family
            tool = x_taxa_tool + ', demovir'
    else:
        order = x_Order
        family = x_Family
        tool = x_taxa_tool + ', demovir'
    return pd.Series([order, family, tool])

# import demovir dataframe
demovir_df = pd.read_csv(argv[2], sep='\t')

# iterrate through contig database and pull out demovir assignment if vcontact2 gave 'undetermined'
contig_df[['Order', 'Family', 'taxa_tool']] = contig_df.apply(lambda x: update_demovir_taxa(x['VC'], x['Genome'], x['Order'], x['Family'], x['Genus'], x['taxa_tool'], demovir_df), axis = 1)

# replace all taxa nan values with 'Undetermined'
for i in ['VC', 'Kingdom', 'Phylum', 'Class', 'Order', 'Family', 'Genus']:
    contig_df[i] = contig_df[i].fillna('Unassigned')

########################################################

############## proccess bacphlip table #################

# import bacphlip df
bacphlip_df = pd.read_csv(argv[3], sep = '\t')

# rename bacphlip columns
bacphlip_df.columns = ['Genome', 'bacphlip_virulent', 'bacphlip_temperate', 'bacphlip_result']

# merge contig_df with bacphlip df
contig_df = contig_df.merge(bacphlip_df, on='Genome', how='left')

########################################################

############### process iphop table ####################

# import iphop dataframe
iphop_df = pd.read_csv(argv[4])

# determine if contigs are generalists or specialists (based on if the infect more than one taxa)
iphop_contig_virus_count = pd.DataFrame(iphop_df['Virus'].value_counts()).reset_index()
iphop_contig_virus_count.columns = ['Genome', 'host_count']
iphop_contig_virus_count['gen_v_spec'] = iphop_contig_virus_count.apply(lambda x: 'Generalist' if x['host_count'] > 1 else 'Specialist', axis=1)

# merge general or specialist decisions with contig_df
contig_df = contig_df.merge(iphop_contig_virus_count, on='Genome', how='left') 

# replace nan's
contig_df['gen_v_spec'] = contig_df['gen_v_spec'].fillna('Undetermined')

# break host genus contig to specific taxa
iphop_df[['host_domain', 'host_phylum', 'host_clade', 'host_order', 'host_family', 'host_genus']] = iphop_df['Host genus'].str.split(';', 5, expand=True)

# keep only useful contigs
iphop_df = iphop_df[['Virus', 'host_domain', 'host_phylum', 'host_clade', 'host_order', 'host_family', 'host_genus']]

# rename columns
iphop_df.columns = ['Genome', 'host_domain', 'host_phylum', 'host_clade', 'host_order', 'host_family', 'host_genus']

# merge this with contig df
contig_df = contig_df.merge(iphop_df, on='Genome', how='left')

# fill na's
for i in ['host_domain', 'host_phylum', 'host_clade', 'host_order', 'host_family', 'host_genus']:
    contig_df[i] = contig_df[i].fillna(i.split('host_')[-1][0] + '__Undetermined')

########################################################

########## Write the master table to file ##############

contig_df.to_csv(argv[5], sep = '\t', index=False)

########################################################

