from sys import argv
from glob import glob
import pandas as pd

# argv[1] = path to file containing total read counts per sample
# argv[2] = path to folder containing processed mpileup files
# argv[3] = path to output the processed and total-sum normalised counts to as long table
# argv[4] = path to the total-sum normalised read counts in the style of an otu table to

# import total number of reads in the samples
total_reads_count_df = pd.read_csv(argv[1], sep='\t', names=['sample', 'read_no'])

# import all mpileup files and use to create new pandas dataframe
mpileup_df = []
for i in glob(argv[2] + '/*_mpileup_cov.tsv'):
    sub_df = pd.read_csv(i, sep='\t')
    sub_df['sample'] = i.split('_mpileup_cov.tsv')[0].split('/')[-1]
    mpileup_df.append(sub_df)
mpileup_df = pd.concat(mpileup_df).reset_index(drop=True)

# process mpileup df to set coverages to 0 for any contig that less than 75% of its length has been covered by at least 1x coverage
mpileup_df['width_adjusted_counts'] = mpileup_df.apply(lambda x: 0 if x['proportion'] < 0.75 else x['no_mapped_reads'], axis=1)

# normalise read counts by contig length (i.e. counts/base)
mpileup_df['length_normalised_counts'] = mpileup_df['width_adjusted_counts'] / mpileup_df['length']

# total-sum normalise each read set by dividing the normalised reads by the total number of quality filtered reads in the sample (could be multiprocessed)
mpileup_df['total-sum_normalised'] = mpileup_df.apply(lambda x: (x['length_normalised_counts']/total_reads_count_df['read_no'][total_reads_count_df['sample'] == x['sample']].iloc[0]), axis=1)

# replace any nan values in the total-sum normalised column with 0s
mpileup_df['total-sum_normalised'] = mpileup_df['total-sum_normalised'].fillna(0)

# output the mpileup_df to a file
mpileup_df.to_csv(argv[3], sep = '\t', index = False)

# output total-sum_normalised otu table
mpileup_df.pivot(index='name', columns='sample', values= 'total-sum_normalised').to_csv(argv[4], sep = '\t', index = False)



