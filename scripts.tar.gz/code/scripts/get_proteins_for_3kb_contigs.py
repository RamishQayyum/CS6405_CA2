import pandas as pd
from Bio import SeqIO
from sys import argv

proteins = argv[1]
contigs = argv[2]

contig_list = []
for record in SeqIO.parse(contigs, 'fasta'):
    contig_list.append(record.id)



seq_list = []
for record in SeqIO.parse(proteins, 'fasta'):
    if '_'.join(record.id.split('_')[:-1]) in contig_list:
        seq_list.append(record)

SeqIO.write(seq_list, argv[3], 'fasta')
