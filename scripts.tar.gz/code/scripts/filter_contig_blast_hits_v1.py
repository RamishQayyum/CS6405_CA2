import pandas as pd
from sys import argv
from Bio import SeqIO
import numpy as np
import multiprocessing
from functools import partial

# input variable
# argv[1] = blast file path
# argv[2] = blasted fasta file path
# argv[3] = output file path
# argv[4] = pid cut off as % 
# argv[5] = length cut off as proportion i.e. 90% = 0.9
# argv[6] = no. threads to use

def split_df_for_multiproc(df,threads):
    chunk_size = int(len(df['qseqid'].unique())/threads)
    if chunk_size == 0:
        chunk_size = 1
    chunk_names = [list(df['qseqid'].unique())[i:i + chunk_size] for i in range(0, len(df['qseqid'].unique()), chunk_size)]
    chunks = [df[df['qseqid'].isin(chunk)] for chunk in chunk_names]
    pool = multiprocessing.Pool(processes=threads)
    return chunks, pool

def multiprocess_check_total_bases_covered(df):
    new_df = {'qseqid':[], 'sseqid': [], 'qlen':[], 'slen':[], 'covered_base_length': []}
    for i in df['combo'].unique():
        ranges = 0
        ranges = set()
        for index, row in df[df['combo'] == i].iterrows():
            start = min([row['qstart'], row['qend']])
            end = max([row['qstart'], row['qend']])
            ranges.update(range(start - 1 , end))
        new_df['qseqid'].append(row['qseqid'])
        new_df['sseqid'].append(row['sseqid'])
        new_df['qlen'].append(row['qlen'])
        new_df['slen'].append(row['slen'])
        new_df['covered_base_length'].append(len(ranges))  # issue around here where simple table contains some with value > 1
    new_df = pd.DataFrame.from_dict(new_df)
    return new_df

# import blast table

df = pd.read_csv(argv[1], sep = '\t', names=['qseqid', 'sseqid', 'pident', 'length', 'mismatch', 'gapopen', 'qstart', 'qend', 'qlen', 'sstart', 'send', 'slen', 'evalue', 'bitscore'])

# drop all self blasting results

df = df[df['qseqid'] != df['sseqid']]

# do initial filter to remove any matches that are < X% id 

df = df[df['pident'] >= float(argv[4])].reset_index(drop=True)

# add column to simplify qseqid sseqid checking

df['combo'] = df['qseqid'] + '~' + df['sseqid']

# make temp df that hold qseqid sseqid pairs that appear more than once

multi_df = df[df.groupby('combo')['combo'].transform('size') > 1].reset_index(drop= True)

# remove those multi ones from main df

df = df[df.groupby('combo')['combo'].transform('size') == 1].reset_index(drop= True)

# add covered_base_length column to main df

df['covered_base_length'] = df.apply(lambda x: max([x['qstart'], x['qend']]) - min([x['qstart'], x['qend']]) + 1, axis = 1)

# split multi df ahead of multi thread processing

chunks, pool = split_df_for_multiproc(multi_df,int(argv[6])) # may need to modify this to x names per chunk as dont want one name to be split over multiple threads

# for each qseqid match check the total bases covered by the each sseqid result (in case some hits are given as multiple hits by blastout)

multi_df = pd.concat(pool.map(partial(multiprocess_check_total_bases_covered), chunks)).reset_index(drop=True)

# give single hit df the same number of columns as multi

df = df[['qseqid', 'sseqid', 'qlen', 'slen', 'covered_base_length']]

# merge the two dfs

df = pd.concat([df, multi_df]).reset_index(drop=True)

# calculate proportion of contig covered by hit

df['hit_prop'] = df['covered_base_length'] / df['qlen']

# filter to only keep contigs with over X % coverage

df = df[df['hit_prop'] >= float(argv[5])].reset_index(drop=True)

# make list of qseqids where contigs qlen were smaller than slen

remove_contigs = list(df['qseqid'][df['qlen'] < df['slen']].unique())

# make list of qseqids where contigs qlen is same as slen

same = df[(df['qlen'] == df['slen']) & ((~df['qseqid'].isin(remove_contigs)) & (~df['sseqid'].isin(remove_contigs)))]

# add everything but the first instance of a unique qseqid to the smaller_hit list

for index, row in same.iterrows():
    if not row['qseqid'] in remove_contigs:
        remove_contigs.append(row['sseqid'])

# create list of seq records that aren't in the remove contigs list (i.e. the good contigs we want)

keep_contigs = []
for record in SeqIO.parse(argv[2], 'fasta'):
    if record.id not in remove_contigs:
        record.description = ''
        record.name = ''
        keep_contigs.append(record)

# output the contigs to keep in fasta format

SeqIO.write(keep_contigs,argv[3],'fasta')

