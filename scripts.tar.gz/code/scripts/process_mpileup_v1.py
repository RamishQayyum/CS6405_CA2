import pandas as pd
from sys import argv
from Bio import SeqIO

# argv[1] = a single mapping mpileup file
# argv[2] = the corresponding idxstats file
# argv[3] = fasta file containing contigs that were mapped to
# argv[4] = output file path

# import pileup output and idxstats output
pileup = pd.read_csv(argv[1], sep='\t', names = ['name', 'pos', 'n', 'number_reads_cov', 'base', 'quality'])
idxstats = pd.read_csv(argv[2], sep='\t', names = ['name', 'length', 'no_mapped_reads', 'no_unmapped_reads'])

# remove any rows with 0 read coverage from pileup
pileup = pileup[pileup['number_reads_cov'] > 0]

# count number of rows containing a given contigs name in pileup (will be one per base covered) and overwrite pileup df
pileup = pd.DataFrame(pileup['name'].value_counts()).reset_index()

# have contingency in the even that the dataframe is empty
if len(pileup) == 0:
    pileup = pd.DataFrame(columns=['A', 'B'])

# rename the columns of the counted pileup
pileup.columns = ['name', 'covered_bases']

# drop unnecessary columns from idxstats df
idxstats = idxstats[['name', 'length', 'no_mapped_reads']]

# join pileup and idxstats 
pileup = pileup.merge(idxstats, on='name').reset_index(drop=True)

# calculate the proportion of bases in the contig with at least 1x coverages
pileup['proportion'] = pileup['covered_bases']/pileup['length']

# get list of contigs add hit by reads
found = pileup['name'].unique()

# create empty dataframe to house contigs that had no mapped reads
missing = {'name': [], 'covered_bases': [], 'length': [], 'no_mapped_reads': [], 'proportion':[]}

# parse the contig fasta to collect see all contig names and add those missing from the 'found' list to the 'missing' dataframe and set the values of these to 0
for record in SeqIO.parse(argv[3], 'fasta'):
    if record.id not in found:
        missing['name'].append(record.id)
        missing['covered_bases'].append(0)
        missing['length'].append(len(record.seq))
        missing['no_mapped_reads'].append(0)
        missing['proportion'].append(0.0)
missing = pd.DataFrame.from_dict(missing)

# join the 'missing' dataframe to the one pileup results
pileup = pd.concat([pileup, missing])

# write table to to file
pileup.to_csv(argv[4], sep='\t', index=False, header=True)


