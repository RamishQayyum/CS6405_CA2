import pandas as pd
from sys import argv
import numpy as np
from Bio import SeqIO
from collections import Counter

# {input.orfs} {input.nucl} {input.virsorter} {input.dvf}
# input variable
# argv[1] = path to file with list of good contigs from proteins searches
# argv[2] = path to file with list of good contigs from nucl searches
# argv[3] = path to virsorter score file
# argv[4] = path to dvf score file
# argv[5] = path to circular contigs file
# argv[6] = path to nr contigs fasta
# argv[7] = output file path


# collect list of good contigs from the filtered protein blast output

prot_contig_list = []
with open(argv[1]) as prot:
    for contig in prot: 
        contig = contig.strip()
        prot_contig_list.append(contig)

# collect list of good contigs from the filtered nucl blast output
nucl_contig_list = []
with open(argv[2]) as nucl:
    for contig in nucl: 
        contig = contig.strip()
        nucl_contig_list.append(contig)


# collect and filter list of good contigs from virsorter output

# load virsorter input
virsorter = pd.read_csv(argv[3], sep='\t')

# filter virsorter contigs to keep only contigs with score ≥0.9 or score of ≥0.7 with at least one viral hallmark protein-coding gene present
virsorter = virsorter[(virsorter['max_score'] >= 0.9) | ((virsorter['max_score'] >= 0.7) & (virsorter['hallmark'] >=1))].reset_index(drop=True)

# extract contig name from seqname column of virsorter table
virsorter['qseqid'] = virsorter['seqname'].str.split('|').str[0]

# get list of the virsorter contigs that passed filtering steps above
virsorter_contig_list = list(virsorter['qseqid'].unique())


# import dvf output table
dvf = pd.read_csv(argv[4], sep='\t')

# filter dvf table to only keep contigs with pvalue < 0.05
dvf = dvf[dvf['pvalue'] < 0.05]

# get list of dvf contigs that passed filtering
dvf_contig_list = list(dvf['name'].unique())

# read VRCA circular fasta and make into list
circular_list = []
for record in SeqIO.parse(argv[5], 'fasta'):
    circular_list.append(record.id)

# combine all the lists of contigs passing the filters for each method
good_contigs = prot_contig_list + nucl_contig_list + virsorter_contig_list + dvf_contig_list + circular_list

# remove redundancy from the good contigs list to keep only each contig name only once
good_contigs = list(set(good_contigs))

# extract contigs passing screening filters from the nr contig db
keep_contigs = []
for record in SeqIO.parse(argv[6], 'fasta'):
    if record.id in good_contigs:
        keep_contigs.append(record)

# output the contigs to keep in fasta format
SeqIO.write(keep_contigs,argv[7],'fasta')

