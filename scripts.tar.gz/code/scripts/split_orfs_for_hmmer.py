from Bio import SeqIO
from sys import argv
from decimal import Decimal, ROUND_HALF_UP

# argv[1] = fasta file to split
# argv[2] = how many ways to split it
# argv[3] = prefix (including path)
# argv[4] = output file extension


records = []

argv[2] = int(argv[2])

for record in SeqIO.parse(argv[1], 'fasta'):
    records.append(record)

seq_bins = {}
for i in range(1, argv[2] + 1):
    if i == 1:
        seq_bins[i] = records[:int(Decimal(len(records)/argv[2]).quantize(0, ROUND_HALF_UP))]
    elif i == argv[2]:
        seq_bins[i] = records[int(Decimal(len(records)/argv[2]).quantize(0, ROUND_HALF_UP)*(i-1)):]
    else:
        seq_bins[i] = records[int(Decimal(len(records)/argv[2]).quantize(0, ROUND_HALF_UP)*(i-1)):int(Decimal(len(records)/argv[2]).quantize(0, ROUND_HALF_UP)*i)]

for i in range(1, argv[2] + 1):
    SeqIO.write(seq_bins[i], '{}_{}{}'.format(argv[3], i, argv[4]), 'fasta')
